package com.antstudios.beats;

import android.app.Activity;

public class SplashActivity extends Activity {
}
